package uk.ac.ed.inf.aqmaps.webserver;

@SuppressWarnings("serial")
public class SendRequestException extends Exception {
  public SendRequestException(String message) {
    super(message);
  }
}
