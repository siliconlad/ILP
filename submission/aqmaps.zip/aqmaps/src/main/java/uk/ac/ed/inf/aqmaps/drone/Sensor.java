package uk.ac.ed.inf.aqmaps.drone;

public class Sensor {
  public String location;
  public Double battery;
  public String reading;
  public Coordinates coordinates;
}
